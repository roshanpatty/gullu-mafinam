Gullu Apology — Ready-to-deploy (Vite + React + Tailwind)

How to deploy (super easy):
1. Upload this ZIP to Vercel: https://vercel.com/new   -> Choose 'Import Project' and upload the ZIP.
2. OR upload the contents of the ZIP to Netlify drag-and-drop at https://app.netlify.com/drop
3. Vercel/Netlify will build the site automatically (they install dependencies and run the 'build' script).
4. After deployment you'll get a public URL. Create a QR code for that URL and surprise Gullu!

Local development (optional):
1. Extract ZIP
2. Run: npm install
3. Run: npm run dev
4. Open http://localhost:3000

Footer text: Made with love by Roshu ❤️
Title: For Gullu — my one and only Kuchuu Puchuu 🌼